Petroglyphs

A simple ORM-based settings manager and injector for Django